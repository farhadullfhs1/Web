const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const port = 3000;

const app = express();
const conn = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'loginn',
    port: 4306
});


conn.connect((err) => {
  if (err) {
    console.error('Database connection failed: ' + err.stack);
    return;
  }
  console.log('Connected to the database');
});

app.use(bodyParser.urlencoded({ extended: true }));

app.use('/addtocart', (req, res, next) => {
  const query = 'SELECT * FROM cart1'; // Replace 'products' with your table name
  conn.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching product data: ' + err);
      return res.status(500).send('Internal Server Error');
    }
    req.products = results; // Store the fetched products in the request object
    next();
  });
});

app.get('/addtocart', (req, res) => {
  const products = req.products; // Use the fetched products to display on the page
  res.render('cart_colection', { products:products }); // Pass products data to the cart page
});

app.post('/addtocart', (req, res) => {
  // Retrieve the selected product details from the request body
  const { name, descr, price, dprice } = req.body;

  // Insert the selected product into the database
  const insertQuery = 'INSERT INTO cart1 (name, descr, price, dprice) VALUES (?, ?, ?, ?)';
  conn.query(insertQuery, [name, descr, price, dprice], (err, results) => {
    if (err) {
      console.error('Error inserting product into cart: ' + err);
      return res.status(500).send('Internal Server Error');
    }
    console.log('Product added to cart successfully.');
    
    // Redirect the user back to the "Add to Cart" page
    res.redirect('/addtocart');
  });
});


app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
