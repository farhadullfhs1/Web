const express = require('express');
const mysql = require('mysql2/promise');
const path = require('path');

const app = express();
const port = 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

const pool = mysql.createPool({
    host: 'localhost',
    user: 'your_username',
    password: 'your_password',
    database: 'your_database'
});

app.use(express.urlencoded({ extended: true }));

app.get('/', async (req, res) => {
    try {
        const [cartItems] = await pool.query('SELECT * FROM cart WHERE user_id = ?', [user_id]);
        let grand_total = 0;

        for (const item of cartItems) {
            grand_total += item.prod_price * item.quantity;
        }

        res.render('cart', { cartItems, grand_total });
    } catch (error) {
        console.error(error);
        res.status(500).send('An error occurred.');
    }
});

app.post('/update', async (req, res) => {
    const { update_quantity, update_quantity_id } = req.body;

    try {
        await pool.query('UPDATE cart SET quantity = ? WHERE id = ?', [update_quantity, update_quantity_id]);
        res.redirect('/cart');
    } catch (error) {
        console.error(error);
        res.status(500).send('An error occurred.');
    }
});

app.get('/remove/:id', async (req, res) => {
    const remove_id = req.params.id;

    try {
        await pool.query('DELETE FROM cart WHERE id = ?', [remove_id]);
        res.redirect('/cart');
    } catch (error) {
        console.error(error);
        res.status(500).send('An error occurred.');
    }
});

app.get('/delete_all', async (req, res) => {
    try {
        await pool.query('DELETE FROM cart WHERE user_id = ?', [user_id]);
        res.redirect('/cart');
    } catch (error) {
        console.error(error);
        res.status(500).send('An error occurred.');
    }
});

app.listen(port, () => {
    console.log(`Server started on http://localhost:${port}`);
});
