const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const authentication = require('./authentication');
const session = require('express-session');
const bparser = require('body-parser');
const { error } = require('console');
const port = 4000;

const app = express();
const conn = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'loginn',
    port: 4306
});

conn.connect();





app.use(express.static(path.join(__dirname, '../html')));
app.use(bparser.urlencoded({ extended: true }));



app.set('view engine', 'ejs');

app.set('views', path.join(__dirname, '../views'));

app.use(session({
    secret: "amatarasu101",
    resave: false,
    saveUninitialized: true
}));


app.use((req, res, next) => {
    if (!req.session.cart) {
        req.session.cart = [];
    }
    next();
});

// route for login 
app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname, "../login2.html"));

});


function isproduct(cart, id) {
    for (let i = 0; i < cart.length; i++) {
        if (cart[i].id == id) {
            return true;
        }
        return false;
    }
}

function producttotal(cart, req) {
    total = 0;
    for (let i = 0; i < cart.length; i++) {
        if (cart[i].dprice) {
            total = total + (cart[i].dprice * cart[i].quantity);

        }

    }
    req.session.total = total;
    return total;
}




// route for register.css files

app.get('/register_css', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/register.css"));

});

app.get('/login2_css', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/login2.css"));

});


app.get('/access_css', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/accessories.css"));

});



app.get('/access2_css', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/accessories2.css"));

});

app.get('/admincss', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/adminlog.css"));

});


app.get('/admin_page_css', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/admin.css"));

});


app.get('/stylecart', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/cart.css"));

});


app.get('/contact_style', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/contacts.css"));

});


app.get('/cover_style', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/cover.css"));

});



app.get('/qa', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/faqs.css"));

});


app.get('/pasand', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/favourites.css"));

});


app.get('/gloves_s', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/gloves.css"));

});


app.get('/kids_css', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/kids.css"));

});


app.get('/kids1', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/kids1.css"));

});

app.get('/kids2', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/kids2.css"));

});


app.get('/kids3', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/kids3.css"));

});

app.get('/men_style', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/men.css"));

});


app.get('/privacy_css', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/privacy.css"));

});


app.get('/men1', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/product1.css"));

});
app.get('/men2', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/product2.css"));

});
app.get('/men3', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/product3.css"));

});



app.get('/returns_css', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/returns.css"));

});


app.get('/sales_css', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/sales.css"));

});


app.get('/testimon_css', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/testimon.css"));

});


app.get('/umbrella_css', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/umbrella.css"));

});
app.get('/w1', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/women_product1.css"));

});
app.get('/w2', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/women_product2.css"));

});
app.get('/w3', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/women_product3.css"));

});
app.get('/wm', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/women.css"));

});


// route for home css

app.get('/home_css', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/actual.css"));

});


app.get('/otp', function (req, res) {
    res.sendFile(path.join(__dirname, "../css/forgot.css"));

});








// route for image files



// image2
app.get('/image2', function (req, res) {
    res.sendFile(path.join(__dirname, "../images/rainy1.jpg"));

});



app.get('/night',function (req,res) {
    res.sendFile(path.join(__dirname,'../images/ani_rain.gif'));
})


app.get('/boss_jpg',function (req,res) {
    res.sendFile(path.join(__dirname,'../images/vegeta.gif'));
})


app.get('/imagess', function (req, res) {
    res.sendFile(path.join(__dirname, "../images/sunset.jpg"));

});




// image3
app.get('/image3', function (req, res) {
    res.sendFile(path.join(__dirname, "../images/devices.jpg"));

});

app.get('/image1', function (req, res) {
    res.sendFile(path.join(__dirname, "../images/actual_rain.jpg"));

});


app.get('/image4', function (req, res) {
    res.sendFile(path.join(__dirname, "../images/forgot.jpg"));

});


app.get('/logo_img', function (req, res) {
    res.sendFile(path.join(__dirname, "../feemo2.png"));

});



app.get('/umbrella', function (req, res) {
    res.sendFile(path.join(__dirname, '../images/pink_umbrella.jpg'));
})


// favourites ka icon 
app.get('/favor_img', function (req, res) {
    res.sendFile(path.join(__dirname, '../images/favourites.png'));
})

// women 3
app.get('/women3_img', function (req, res) {
    res.sendFile(path.join(__dirname, '../images/women3.jpg'));
})


app.get('/kids2_img', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/kids2.jpg'));
})


app.get('/search', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/search (2).png'));
})



app.get('/cart', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/cart.png'));
})

app.get('/nocart', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/nocart.png'));
})



app.get('/account', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/account.png'));
})



// gloves
app.get('/gloves_img', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/gloves.jpg'));
})

// cover 
app.get('/cover_img', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/mobile_cover.jpg'));
})

app.get('/men_raincoat_img', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/men_raincoat.jpg'));
})


app.get('/women_raincoats_img', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/women_raincoat.jpg'));
})



app.get('/kids_raincoats_img', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/kids_raincoat.jpg'));
})

// icons 
app.get('/shipping_img', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/free-shipping.png'));
})


app.get('/return_img', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/return.png'));
})


app.get('/warranty_img', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/warranty.png'));
})


app.get('/shopping_bag_img', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/shopping-bag.png'));
})


app.get('/insta_img', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/insta.png'));
})


app.get('/fb_img', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/fb.png'));
})



app.get('/youtube_img', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/tube.png'));
})



app.get('/visa', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/visa.jpg'));
})


app.get('/mastercard', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/mastercard.jpg'));
})


app.get('/paypal', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../images/paypal.jpg'));
})

app.get('/dash',function (req,res) {
    res.sendFile(path.join(__dirname,'../images/dashboard.png'));
})

app.get('/order',function (req,res) {
    res.sendFile(path.join(__dirname,'../images/order-now.png'));
})


app.get('/customer',function (req,res) {
    res.sendFile(path.join(__dirname,'../images/customer.png'));
})


app.get('/noadmins',function (req,res) {
    res.sendFile(path.join(__dirname,'../images/software-engineer.png'));
})


app.get('/wallet',function (req,res) {
    res.sendFile(path.join(__dirname,'../images/wallet.png'));
})


app.get('/pending',function (req,res) {
    res.sendFile(path.join(__dirname,'../images/pending.png'));
})













// html files

app.get('/login', function (req, res) {
    res.sendFile(path.join(__dirname, "../login2.html"));

});
app.get('/admin_page',authentication, function (req, res) {
    res.sendFile(path.join(__dirname, "../admin.html"));

});


// app.get('/home',authentication,function (req,res) {
//     res.render('home');

// });

// route for register page
app.get('/signin', function (req, res) {
    res.sendFile(path.join(__dirname, "../register.html"));

});


app.get('/dashbo', function (req, res) {
    res.render('dashboard1');

});






app.get('/product_list',authentication, function (req, res) {

    conn.query('select * from products',function (err,results) {

        // results.forEach(function (item) {
        //     item.image = Buffer.from(item.image,'binary');

        //     rimage = item.image.toString('base64');

        // })

        res.render('admin_product_list',{results:results});
        
    })

});








app.get('/orderss', function (req, res) {
    conn.query('select * from orders',function (err,result) {
        
        res.render('orders',{result:result});
    })

});

// edit user accounts page 
app.get('/customers_accounts', function (req, res) {
    conn.query('select * from user',function (err,result) {
        
        res.render('customers',{result:result});
    })

});



// edit admins_accounts page
app.get('/adminacc', function (req, res) {
    conn.query('select * from admins',function (err,result) {
        
        res.render('adminacn',{result:result});
    })

});

// admin page logout
app.get('/admin_logout', function (req, res) {
    req.session.destroy(function (err) {
        if (err) {
            console.error("Error logout!");
            res.send("<script> alert('Error while logging out...TRY AGAIN'); </script>");
        }
        else {
            res.send("<script> alert('Logged Out Succesfully');  window.location.href = '/admin_login'; </script>");
        }
    })

});


// route for contact us 
app.get('/contact_us', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, "../contacts.html"));

});

app.get('/about', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, "../about.html"));

});


// app.get('/cart_collection',authentication,function (req,res) {
//     res.sendFile(path.join(__dirname,"../cart_collection.html"));

// });

// route for home 
app.get('/home', authentication, function (req, res) {
    conn.query("select * from products", function (err, result) {
        if (err) {
            console.error('Error fetching products:', err);
            res.status(500).send('Error fetching products');
            return;
          }
      
          result.forEach(function (item) {
            item.imageBase64 = item.image.toString('base64');
          });
      
          res.render('home', { result: result });
        });
        
    });






app.get('/logout', function (req, res) {
    req.session.destroy(function (err) {
        if (err) {
            console.error("Error logout!");
            res.send("<script> alert('Error while logging out...TRY AGAIN'); </script>");
        }
        else {
            res.send("<script> alert('Logged Out Succesfully');  window.location.href = '/'; </script>");
        }
    })

});




// forgot password
app.get('/forgot', function (req, res) {
    res.sendFile(path.join(__dirname, "../forgot.html"));

});

// sales
app.get('/sales', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, "../sales.html"));

});

// accesories
app.get('/access', authentication, function (req, res) {
    conn.query("select * from accessories", function (err, result) {

        
        res.render('accesories', { result: result });
    });

});

// accessories2
app.get('/access2', authentication, function (req, res) {
    conn.query("select * from access2", function (err, result) {

        
        res.render('accessories2', { result: result });
    });

});



// umbrella
app.get('/umbrella1', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, "../umbrella.html"));

});

app.get('/women3_html', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../women_products3.html'));
})


app.get('/favor_html', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../favourites.html'));
})



// kidsimage2
app.get('/kids2', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../kids2.html'));
})



// glove
app.get('/gloves1', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../gloves.html'));
})


// mobile cover
app.get('/cover_html', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../cover.html'));
})


// men raincoats page
app.get('/men_raincoats_html', authentication, function (req, res) {
    conn.query("select * from mens", function (err, result) {

        
        res.render('men_raincoats', { result: result });
    });
})

// women raincoats page 
app.get('/women_raincoats_html', authentication, function (req, res) {
    conn.query("select * from women", function (err, result) {

        
        res.render('womens', { result: result });
    });
})


app.get('/kids_raincoats_html', authentication, function (req, res) {
    conn.query("select * from kids", function (err, result) {

        
        res.render('kids', { result: result });
    });
})


app.get('/faqs_html', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../faqs.html'));
})


app.get('/testimony_html', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../testimon.html'));
})


app.get('/policy_html', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../privacy.html'));
})


app.get('/returns_html', authentication, function (req, res) {
    res.sendFile(path.join(__dirname, '../returns.html'));
})
















// database handle for login
app.post('/login', function (req, res) {
    const emails = req.body.email;
    const passi = req.body.pass;

    const query = "select * from user where emails = ? and passi = ?";

    conn.query(query, [emails, passi], function (err, results) {
        if (err) throw err;
        if (results.length > 0) {


            req.session.users = [{ email: emails, passi: passi }];
            res.send("<script> window.location.href = '/home'; </script>");
        }
        else {
            res.send("<script> alert('Wrong password ! TRY AGAIN'); window.location.href = '/'; </script>");


        }


        // if (results.length ===1) {
        //     const proname = results[0].fname;

        //     req.session.proname = proname;
        //     res.redirect('/home');
        // }


    });
});




app.post('/admin_login', function (req, res) {
    const aemail = req.body.aemail;
    const apass = req.body.apass;
    const aname = req.body.aname;

    const query = "select * from admins where aemail = ? and apass = ? and aname = ?";

    conn.query(query, [aemail, apass,aname], function (err, result) {
        if (err) throw err;
        if (result.length > 0) {


            req.session.users = [{ aemail: aemail, apass: apass,aname:aname }];
            res.send("<script> window.location.href = '/admin_page'; </script>");
        }
        else {
            res.send("<script> alert('Wrong inputs ! TRY AGAIN'); window.location.href = '/admin_login'; </script>");


        }


    });
});



app.get('/admin_login',function (req,res) {
    res.sendFile(path.join(__dirname,'../admin_login.html'));
})



// database handle for register

app.post('/signin', function (req, res) {
    const emails = req.body.email;
    const passi = req.body.pass;
    const fname = req.body.fname;
    const lname = req.body.lname;

    const query = "insert into user values(?,?,?,?)";

    conn.query(query, [fname, lname,emails,passi], function (err, results) {
        if (err) throw err;
        res.redirect('/login');




        console.error(err);


    });
});


app.use('/addtocart', (req, res, next) => {
    const query = 'SELECT * FROM cart1'; // Replace 'products' with your table name
    conn.query(query, (err, results) => {
      if (err) {
        console.error('Error fetching product data: ' + err);
        return res.status(500).send('Internal Server Error');
      }
      req.products = results; // Store the fetched products in the request object
      next();
    });
  });






  app.post('/addtocart', (req, res) => {
    // Retrieve the selected product details from the request body
    const { name, descr, price, dprice } = req.body; 
    // if (!image) {
    //     console.error('Image data is missing or null.');
    //     return res.status(400).send('Image data is missing or null.');
    //   }
  
   const insertQuery = 'INSERT INTO cart1 (name, descr, price, dprice) VALUES (?, ?, ?, ?)';
  conn.query(insertQuery, [name, descr, price, dprice], (err, results) => {
    if (err) {
      console.error('Error inserting product into cart: ' + err);
      return res.status(500).send('Internal Server Error');                 
    }
    console.log('Product added to cart successfully.');
    
    
    res.redirect('/addtocart');

  
    
  });
  });
  



  app.get('/addtocart', (req, res) => {
    const query = 'SELECT * FROM cart1'; 
    conn.query(query, (err, cart) => {
      if (err) {
        console.error('Error fetching cart data: ' + err);
        return res.status(500).send('Internal Server Error');
      }
  
    //   // Convert BLOB image data to Base64 for each item in the cart
    //   cart.forEach(function (item) {
    //     item.imageBase64 = item.image.toString('base64');
    //   });
    var products = req.products;
  
      res.render('cart_collection', { cart: products }); 
    });
  });
  



    // css 
    app.get('/carty_css', function (req, res) {
        res.sendFile(path.join(__dirname, '../css/carty.css'));
    })


    
    // In your Express app, update the '/edit' route as follows:

    app.post('/edit', (req, res) => {
        const itemId = req.body.id;
        const action = req.body.increase ? 'increase' : req.body.decrease ? 'decrease' : null;
      
        if (!action) {
          // Handle invalid action
          res.status(400).send('Invalid action');
          return;
        }
      
        // Query the database to get the current quantity
        conn.query('SELECT quantity FROM cart1 WHERE id = ?', [itemId], (err, results) => {
          if (err) {
            console.error('Error querying the database:', err);
            res.status(500).send('Error updating quantity');
            return;
          }
      
          const currentQuantity = results[0].quantity;
          let newQuantity;
      
          if (action === 'increase') {
            newQuantity = currentQuantity + 1;
          } else if (action === 'decrease' && currentQuantity > 1) {
            newQuantity = currentQuantity - 1;
          } else {
            // Handle invalid action
            res.status(400).send('Invalid action');
            return;
          }
      
          // Update the quantity in the database
          conn.query('UPDATE cart1 SET quantity = ? WHERE id = ?', [newQuantity, itemId], err => {
            if (err) {
              console.error('Error updating quantity in the database:', err);
              res.status(500).send('Error updating quantity');
              return;
            }
      
            res.redirect('/addtocart');
          });
        });
      });







// delete admin accounts logic
app.post('/remove_admin', function (req, res) {

    var aemail = req.body.aemail;

    const query = "delete from admins where aemail = ?";
    
    conn.query(query,[aemail],function (err,results) {
        if (err) {
            res.send("<script> alert(Can't delete due to some issue !..);");
            console.error("The error found is :",err);
        }
        else{
            res.send("<script> alert('Deleted successfully!'); window.location.href = '/adminacc'; </script>");

        }
    })
    }

)


// for updating admin accounts
app.post('/update_admin', function (req, res) {

    var aname = req.body.aname;
    var aemail = req.body.aemail;
    var ID = req.body.ID;

    const query = "update admins set aname = ? , aemail = ? where aID = ?";
    
    conn.query(query,[aemail,aname,ID],function (err,results) {
        if (err) {
            res.send("<script> alert(Can't update due to some issue !..);");
            console.error("The error found is :",err);
        }
        else{
            res.send("<script> alert('Updated successfully!'); window.location.href = '/adminacc';</script>");

        }
    })
    }

)




    app.post('/remove', function (req, res) {

        var cart = req.session.cart;
        var id = req.body.id;

        for (let i = 0; i < cart.length; i++) {
            if (cart[i].id == id) {
                cart.splice(cart.indexOf(i), 1);
            };

            producttotal(cart, req);

            res.redirect('/cart_collection');
        }
    }
    )


    app.post('/contact_us', function (req, res) {
        const name = req.body.name;
        const email = req.body.email;
        const phone = req.body.phone;
        const subject = req.body.help;
        const message = req.body.txtarea;
        
    
        const query = "insert into messages values(?,?,?,?,?)";
    
        conn.query(query, [name,email,phone,subject,message], function (err, results) {
            if (err) {
                res.send("<script> alert('Error Occurred!');  </script>");
                console.error('Error is : ',err);
            }
            else{
            res.send("<script> alert('Message Sent!');  window.location.href = '/contact_us'; </script>");

        }
    
    
        });
    });













    // for kids
    app.post('/edit1', function (req, res) {

        var id = req.body.id;
        var increase = req.body.increase;
        var decrease = req.body.decrease;
        var quantity = req.body.quantity;
        var cart = req.session.cart;



        if (increase) {
            for (let i = 0; i < cart.length; i++) {
                if (cart[i].id == id) {
                    if (cart[i].quantity > 0) {
                        cart[i].quantity = parseInt(cart[i].quantity) + 1;
                    }
                    else {
                        res.send("<script> alert('Wrong Input!!'); </script>");
                    }
                }
            };
        };


        if (decrease) {
            for (let i = 0; i < cart.length; i++) {
                if (cart[i].id == id) {
                    if (cart[i].quantity > 1) {
                        cart[i].quantity = parseInt(cart[i].quantity) - 1;
                    }
                    else {
                        res.send("<script> alert('Quantity can't be less than 0 !'); </script>")
                    }
                }
                else {
                    res.send("<script> alert('No product Found'); </script>");
                }
            };
        };

        producttotal(cart, req);

        res.redirect('/cart_collection');


    })

    app.post('/remove1', function (req, res) {

        var cart = req.session.cart;
        var id = req.body.id;

        for (let i = 0; i < cart.length; i++) {
            if (cart[i].id == id) {
                cart.splice(cart.indexOf(i), 1);
            };

            producttotal(cart, req);

            res.redirect('/cart_collection');
        }
    }
    )


    app.listen(port, function () {
        console.log(" Express server started at port 4000");
    });

