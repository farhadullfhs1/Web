import React from "react";
import "./YourStyleSheet.css"; // Replace with the correct path to your CSS file

const ContactUsPage = () => {
  return (
    <div>
      <div className="navbar">
        <img src="feemo2.png" alt="error" className="logo" />
        <input id="txt1" type="text" placeholder="Search" />
        <img className="search" src="/search" alt="" />
        <div className="icons201">
          <a href="/cart_collection" className="cart">
            <img id="carty1" src="/cart" alt="error" />
          </a>
          <img id="carty2" src="/account" alt="error" />
        </div>
      </div>

      <div className="navbar2">
        <div className="categories1">
          <a className="navy2" id="cat_1" href="#">
            Category
          </a>
          <div className="subcat1">
            <a href="/men_raincoats_html" className="imp1">
              Men
            </a>
            <a href="/women_raincoats_html" className="imp1">
              Women
            </a>
            <a href="/kids_raincoats_html" className="imp1">
              Kids
            </a>
          </div>
        </div>
        <a className="navy" href="/contact_us">
          Contact us
        </a>
        <a className="navy" href="/about">
          About Us
        </a>
        <a className="navy" id="navy_1" href="/faqs_html">
          FaqS
        </a>
        <a className="navy" id="logy" href="/logout">
          LogOut
        </a>
      </div>

      <div className="header">
        <h1 className="head1">Get In Touch</h1>
      </div>

      <div className="query1">
        <form action="/contact_us" method="post" id="contact_details">
          <label htmlFor="name">Your Name :</label>
          <br />
          <input type="text" name="name" className="detail1" placeholder="text" />

          <br />
          <br />
          <br />

          <label htmlFor="email">Your Email_ID :</label>
          <br />
          <input
            type="email"
            name="email"
            className="detail1"
            placeholder="Your Email_ID"
            pattern="[A-Z0-9a-z.%+-]+@[a-z]+\.[a-z]{2,}"
          />

          <br />
          <br />
          <br />

          <label htmlFor="phone">Your Contact Number :</label>
          <br />
          <input type="number" name="phone" className="detail1" placeholder="Contact Number" required />

          <br />
          <br />
          <br />

          <br />
          <label htmlFor="help">Subject</label>
          <br />

          <select className="ddl1" name="help" id="help" required>
            <option value="Problem with placing orders">Problem with placing orders</option>
            <option value="Want to place bulk order">Want to place bulk order</option>
            <option value="suggestion for product design">Suggestion for product design</option>
            <option value="product feedback">Product feedback</option>
            <option value="Grievances">Grievances</option>
            <option value="Other Options">Other Options</option>
          </select>

          <br />
          <br />

          <label htmlFor="txtarea">Message</label>
          <br />

          <textarea
            title="msg"
            placeholder="Write your Query"
            name="txtarea"
            id="txt755"
            cols="78"
            rows="10"
          ></textarea>

          <br />
          <br />

          <button title="btn11" type="submit" className="sub1">
            Submit Now
          </button>
        </form>
      </div>
    </div>
  );
};

export default ContactUsPage;