-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:4306
-- Generation Time: Sep 07, 2023 at 10:38 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `loginn`
--

-- --------------------------------------------------------

--
-- Table structure for table `access2`
--

CREATE TABLE `access2` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `descr` varchar(200) NOT NULL,
  `price` int(10) NOT NULL,
  `dprice` int(10) NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `access2`
--

INSERT INTO `access2` (`id`, `name`, `descr`, `price`, `dprice`, `image`) VALUES
(501, 'Feemo PVC Mobile Cover', 'Seam seal is used with tapes. Superior quality Covers.', 900, 799, '/images/mobile_cover.jpg'),
(601, 'LappyRella Waterproof Cover for 15.6 inch Laptop', '🌊 Water-proof Laptop Cover, Dust-proof, Scratch-proof: Have peace of mind in rains. Separate Inside Partition Flap for Laptop and Accessories. No need to search for cables and accessories inside your ', 699, 179, 'https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.amazon.in%2FLappyRella-Waterproof-Laptop-Dustproof-Scratch%2Fdp%2FB07X6QSM79&psig=AOvVaw0MvJiNMnxX__SPrFwSPOei&ust=1693840686348000&source=images&cd=vfe&opi=89978449&ved=0CBAQjRxqFwoTCNj7orXejoEDFQAAAAAdAAAAABAH');

-- --------------------------------------------------------

--
-- Table structure for table `accessories`
--

CREATE TABLE `accessories` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `descr` varchar(200) NOT NULL,
  `price` int(10) NOT NULL,
  `dprice` int(10) NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accessories`
--

INSERT INTO `accessories` (`id`, `name`, `descr`, `price`, `dprice`, `image`) VALUES
(401, 'Feemo PVC Saffari Umbrella for You', 'Seam seal is used with tapes. Superior quality Umbrella.', 300, 150, '/images/favourites.png'),
(402, 'Feemo PVC Saffari Gloves for Everyone', 'Seam seal is used with tapes. Superior quality Gloves.', 500, 350, '/images/gloves.jpg'),
(403, 'Feemo PVC Mobile Covers', 'Seam seal is used with tapes. Superior quality Covers.', 800, 650, '/images/mobile_cover.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `aname` varchar(100) NOT NULL,
  `aemail` varchar(100) NOT NULL,
  `apass` bigint(20) NOT NULL,
  `aID` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`aname`, `aemail`, `apass`, `aID`) VALUES
('Farhadul Zaman', 'farhadullfhs@gmail.com', 123456789, 20);

-- --------------------------------------------------------

--
-- Table structure for table `kids`
--

CREATE TABLE `kids` (
  `name` varchar(100) NOT NULL,
  `descr` varchar(100) NOT NULL,
  `dprice` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `image` varchar(500) NOT NULL,
  `id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kids`
--

INSERT INTO `kids` (`name`, `descr`, `dprice`, `price`, `image`, `id`) VALUES
('Feemo PVC Saffari Raincoat for Kids', 'Seam seal is used with tapes. Superior quality raincoat for kids.', 350, 850, '/images/kids1.jpg', 101),
('Feemo PVC Saffari Raincoat for Kids2', 'Seam seal is used with tapes. Superior quality raincoat for kids.', 500, 1000, '/images/kids2.jpg', 102),
('Feemo PVC Saffari Raincoat for Kids3', 'Seam seal is used with tapes. Superior quality raincoat for kids.', 899, 1500, '/images/kids4.jpg', 103);

-- --------------------------------------------------------

--
-- Table structure for table `mens`
--

CREATE TABLE `mens` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `descr` varchar(200) NOT NULL,
  `price` int(10) NOT NULL,
  `dprice` int(10) NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mens`
--

INSERT INTO `mens` (`id`, `name`, `descr`, `price`, `dprice`, `image`) VALUES
(1, 'Feemo Cloth Reversible Raincoat 1', 'Superior quality best raincoat for men.', 2380, 1380, '/images/men1.jpg'),
(2, 'Feemo Cloth Reversible Raincoat 2', 'Superior quality best raincoat for men.', 2220, 1005, '/images/men2.jpg'),
(3, 'Feemo Cloth Reversible Raincoat 3', 'Superior quality best raincoat for men.', 3000, 1999, '/images/men3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `subject` varchar(10) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`name`, `email`, `phone`, `subject`, `message`) VALUES
('Farhadul Zaman ', 'drago@gmail.com', 456789, 'product fe', 'kjhgjhg jhguhghjh'),
('Farhadul Zaman ', 'farha@gmail.com', 3456789, 'Want to pl', 'kjhghg jhguhg\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `ordered_items`
--

CREATE TABLE `ordered_items` (
  `id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` int(20) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `product_quantity` int(10) NOT NULL,
  `order_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `city` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(12) NOT NULL,
  `date` datetime(6) NOT NULL,
  `cost` bigint(20) NOT NULL,
  `product_ids` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL,
  `transaction_id` bigint(20) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` varchar(100) NOT NULL,
  `name` varchar(30) NOT NULL,
  `descr` varchar(300) NOT NULL,
  `price` int(10) NOT NULL,
  `dprice` int(10) NOT NULL,
  `image` longblob NOT NULL,
  `quantity` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `descr`, `price`, `dprice`, `image`, `quantity`) VALUES
('p11', 'Feemo pinky umbrella', 'Seam seal is used with tapes for a more waterproofing experience. Superior quality best umbrella.', 300, 150, 0x0000001c667479706176696600000000617669666d6966316d696166000000ea6d657461000000000000002168646c72000000000000000070696374000000000000000000000000000000000e7069746d00000000000100000022696c6f630000000044400001000100000000010e000100000000000016a50000002369696e6600000000000100000015696e6665020000000001000061763031000000006a697072700000004b6970636f00000013636f6c726e636c78000200020006800000000c6176314381040c000000001469737065000000000000027200000272000000107069786900000000030808080000001769706d61000000000000000100010481820384000016ad6d64617412000a0a19266719c78204040d0832942d11400104104140f4bacdcb2f4897a2cc596702a06ededdf47e3fb46b1f90d1a86cb72fe0f56f8acfb3c090793185aa1fc6212d25446acc15ff4a58f2cb295cda65e989c77fb1bf84ca402ebc4e9f03185f4f0a9702b453ce2b8ff1b114ac7f3876a0df987a628586b8f356b4965ddcb415a0089c7baa63d561529e26d49c6523a562816699a7c287d54ddadbfbc71f86a4fc58211435b12707dfdd1f9bad56d69c9b8bc5c79721c2484acf5e0d7630288d5dba9e8bbc18fbc9e072a882105b0bb2f91dae0dbf8dcf453cbcc184e9d577efe942a531b1cf99ba8af29eefc3c300b477cda6e13d6b495ce83c37c4470de986baa0fed8fee7d381d6f4715911417854f88940798974731cb9448b9c37ecbd70742388f0d4289840332f80eb6e0228e7e019d122e8f1fb5f2f362fa0990a3108a1ad6b360bf45d3f6d9844309b9601a45934e6b58bc5a93587aa8b4670840f8380ca98559ab74be084e35f7821a846908f0b449dce5dafc0ab2c8ea59f5f0f7dee80281dbdd8580d276f1118535049683dc497f939c6af516025b7df21f43f682340788b6659b9e31e0403da53e05df901fd48f73be15a74d8bca118b149b7becca72a56e7a7de109253904a2a46450096a1316dc860c86834c040ffdbc1b722b118f90c7b9d8a23b4c4e195c7ca50d74742befd3584b3269e5aa8cccdf1192d02d9ff3a61dd5b59472b4a26c418c390247beb7be6148aa2bc159246561a4e83a80ede029a115406e13346b37207f21636d462080ce2d3348b5c79fec1103598eaeb175d6bbac6789cad8c69dbe9fd1e9456b58ed4eb5ee55479eb9567caed10e682a413ac041b0da96a08f2764793dcebb2195c00f00814a2045f767356ceecfce0bfd66837544f800c7925ad6378ab76e1f81654d7f409b05a1828833fd015bbab3b310bfb7fe40626405bace85a17da44c8c24714ef5ed7cfe4db704307792db29986bead979dbc0ed427ded2359c8b8e07aff354b513d643ca41b75ddbe8275202aae4fc6c0098f68eca44ba7f215e197a7c4a4c55e7c553fd318e4d7aef54962e3343147096b3c68063acb03a5253b18f5a07c0e36a733512903c0f6d67dc110d0c61397588eba19d3aaf5dafc152a20dd156a7e6ecb5bd122129ecd7d558625596920d4d18a9a29336ae5debf671609680ed8adb6db7c0171a5496ba26904991a4531974fceea7a80c4765375b787b763f2311e92a88c7897a2c4d77e6f3fa9d42edf2c1f5ea28c793b3e49c661f5677f588358cd48f24c385cacbd434d71a551e7024f40adba68545623159ed230f03b9e3036bf9342ec8a2603a0742751371b5d587514b1af1002905c830d028c20be1d976da1a0c1c25c9d49d9b91a0291ff385fa86aab8803372196f6f8def36d19edc6608a327b6deb0cb25db8311d0f002d07a5287cf8845d7866fb656cac8dac2653f59210f5e25b7281ddf18b299e0eb7db1f3edc8afbf123f6f741b221505b1857340cbd157e42b5911854981cb1421cbef6f57af76afd62eb646d91b7feb61d80e0625315293d68cae1b7b1f0a28790d44318b3ce1da5691132bc5e39e8e8856a7e6327f76e8c7168e594ce1a1d952662d9eeec656fc9b985a24cb9aa1b07e16cf12e09d5e4b9e02d4c68b4353e5a51cfa90a1afeed55aa3954ab6c170f2fed8d1e2750cd549678fce53c02d5b821589895e8c9751e1f1ee4251d7d7b9ee28a1787154f33da6930bc7ca589573849a76e1bd05c51ebe7b531270d88812d661f3de14fc1ed214bd9bdf8a9123c393763a488b90b0d4d6f63ecf91b702004ee14a7c946ac08962cc2d269d0b25e6e11660336fc3100ad4a8386186e85bf56cbc4f3075bbf1c9d5a5cd088daeeee65df10c63e0cad8e750568917a4f7f71e63a26e845e6ba2fb2d6cc900e07f4d9c919e41838ab91b167b91418a25b186acbcea28c5fe573344dbfad4856a7d5de47a4f65d1aa2928d2f5f6b2e811cd17fda4799b9b980e4602388935ce9d8038dc98d153c4da036a0093b819a2cea4cf277987912ab89383e5356551ab88d1ff8eed9027567cc9c6b07e1d34c8a355097e3273e0a8615510a8403f8d1d91bc4927b187a3047dde1be93c7e53176ed49a76cd344d7d176536cdeb1f2f9a0f186342c554136d864dd976d9a09a2a26309756d1f1ad468fe809afeb96f6c0b505a2f61e3ca38ab96d567f107acf1a55c4f862506064dbea2c7c0b27c0f1fd9ce660e322ac4dacfa1060cca0360190b7c815bee63409ed010444f01534ca0260954f1e6813696e02652467efedead3375e6748a00513c724773f52b582d5e72aae408bc30e1c60ffeb1e6255a098c857afe3e1fe898eb4480d3160744d35c4478a4c60f9eead0a2ecaed1383ee0ec544f468a93f3afd9a470cef8300374ea5f0254e2f4162d79a4d27bf14955f4ccca8131e000d4bc1e0497dc6359d55631b1b5b82e6c305e215a3fc5dae5aa343d679b6ee76883e989a15f600121a3a2ac1902a8b874369da8220d3a6686f4da2530855b698daeb702291ed54b08c82cad5041359ca2177afd197c4967e359b3af8e17bc7328e5bf0800433028ef9f9e8d90175b6645a4bdc09935232b9c8382c91adfb824e41be71528a1e2678daf19b53b59e47d994c9ce213805d621e87fc4c8f6b98cd8b9a2140eab23342b78ea67b6b8d87bc5f41f268e124f1d283401bfede0f4a35423c89cf6cd09707c26caa6a4f0c229911f93711a1358a02063adfd4ee7f80db612c1195c4c7fb699dc072fb0c9fa8cda78ad173e572b250e82b64b59a8137b0117a17d822c28398aa2db769cd7ed23e958582c0ae2642fcaed2ec7884ff02672036dc4532f9922b6e875e5c56413e790c789758262fe678174aa8713fe6590fe4beee9a9f28047a53ce5e8961ea7e85131ab56b6221677fffc206a0737d5579bd316f6eff642d097d88e4366c95e7772331856ba578c21d595925cbeed290e030ca32d40314bd789d381af06a67df663abfd056cdade1b93f2f7437559d94b9fee771173382d783a4e16c998fd1ac72742e50407ec2556966e2f2a597a72c59bd1aebf3ed835a5e4ec4f7d736f33f1cd115d596e130d2901c7e644eba7c31fa642825161a2b776fe3f249afd1ab69b20957e3aae7257f34382bb613320016074930b8b25179636737a503fb69aeced2602bc6d0b416842dd4c32ce5d0ea41dac72e21315d9a10939b51d6f7530481ba8711866bd43fd9725d3f14a63a3cb6e3b72043206f693d0c3c4c7306203bdc03b3d2be6d8e18e38ddce6e268e297907441e553de1878957c3fd19bb309c95801d8c68f3db3776fb11e14163b042f6a01791843fc7cb497eff595a3860c76be11d76c726e9d6a83721c7585aac8a7f61270b5b09958981e9e2d6c8b0a37eda3128bdfa5d71033b2bc696b20a1c372322fb8b13e194d74810fd81861eddaf17b7ea6e6f236166f3769ffbe1f544f3d59c20a3a4600bf9c46e4b4b19b6784cd15a9d0692d79988f835d786ea2413da44f6be41d18be33d533705ad988f938ccd5a9202e80b287e9c99facc0f6bc92a907d51ecf31f76f40b8238e1c87571f9c9716e356008e2a15c02517dbf1012d10d9451e1aff4fb1588a6e02afd88622931bf152e37e4c6e74d11093a0683558891f452024311617fcba734915d0ff8609dceb79ff787de4671928cb7bf024b36de86ff3d9199cb2d62d0cbd37d1e001c23287a0159a94552279135d9f92790a82059b7109cba3cc48ad0b82a66d4e3b41b7687d6c60d1c95429d8e803104dd65d80b9d852b29e7eac45fab5710a02a71569e9417db37f8670f7caa53b46e27780dcfe68fa6191db43911ed768121bf7f865fd7ec21fe72525189e2fecec80db23615708da7e87a5b49681f6e4d5ca6f28c30e6f0ba884059f6eb03813cbed4c5c5562c07313fd2dd9edde0115fc2a6a3ba1911e431b4ab1327d1edf631d911e17b88cbcaadcea19bd9fc3def5bd30f1a87e2abd1ff1f276e41224e8116b91e5060c9d0672183f060e729bc67eb42139172156f2927aa25c9207fd9cd8476676a176ce6d5b7bffd987a1c5f926906cdc1d57c5ecd1ba6d17af77bd310824a270c60ba364ff081d36bdc4bb173b60194eeda6ff1163bc88a6a20a352f154da8eb861c5098ace318951a573ec0a629ccc7e24ab84bf30a781d27111e3c432d392bf7590c9af23b7eb01640f61b52755c33bb937fcaf0b7ef82ecfef817d3da945c45a5cf8c270779aa6a2a6aaef2da86087739140727c506949dba9a78828d17448e162a94e053e59001f8fd70040c1d112dae90f6818ee23dcf8fd19bab603f59a23a9a8655d8901b00d137dae6dc9a615148e62f99f6f28190a2b46a9b71804b5a14cf926cbe461fc452d6e83e4eb0d4fb6c6adf88ff75a6d35091f8f01f72d78ba7fc5994b8855e7a489b496bda431f6b4f9902fc79fb20a906f281ef88aa6267503ef6234f7acc1cc6e4ce3db6bd70a5222c100c81852683f4a94e5aaacae7fefc1e6fb0c612e0bccb26f6702c442ecc18f880a701ed26500e0b7ebb41f649a952c00c30fcd9f237756132127fb5a14a584fa0f2f6f95279bd2f4666de6fac39f956e128861c9d6af8bf7d591c61bcf52c29533bd61311dfbb09aa89751742888d64d7797213cb107ab79799bcfaa903a3888c3837029532ab33fc1c5a021281c998f624b9d694ebe0db2a34ebd2d5b25022360bbf22ffc3588b7be4057a12900a00a2b8d07a39a4cc33ec4f58e3b5b535c242c88072f33f6e746e586ee6576d5c70886ac472856724024cb55074d9803980c859cedc965ffa334f72797766a50cf1bd6fe3eada2d414a3f8863842474e655a88b0e9f445634b1061cc057b886bc7808d801414cd0e7461377cc32e8c84bf89cbb7cabdd778f43f33b1e02a8e089843b741650db30a185e5483b05610de92c86fb10e612afa6e06e63302f281b0a18c7e28b80ad42fb4ca8a9a4f898554e80dd134bded6e3525c3a8483cb471cbac5e1a48e18c2cf9818f490e407b1b0438e5b38ebf351699a82f7d5cea25214af2a356f2d4f53607858054b003bd95a16a05b25ce107c66b4fb72d93f370047815ebe85a3f5a87cb5f3c078fa97a1f942d57cda9fee60d823e5a15a35cadd3c1966d1ce9e82b217ccd49cccc9edcae720d6316ef6ea1a7ef1a7881a56740d20c80f193e852f5e6a70a36f60eb273da5d95557eaebb3c850534bec05f314ad54344f431de2360cfd882818ea088af0c3d5d3bdbc7000373bd6241c508336fc03fe2c504b5f1d91f239c2a64f0f93823280b55a81dcba68337b5dccdfecc0926779aac69fcf656b500220202bf2381f68f79951c98a6d05b15a350f21e344e43ad5d30c55107c0c017967b0c3df6acc8be819b790c94659215e10759f1d73ef060e1dffcd95a596457a546d8028362dcdc107d2fe0fe2780c7d9820e01e50fa4f7994ec6b4a36782634548429e4accfe13c4b17c1360ad82f9f161dd391c65c892a9a418fcbe6143cd35e8763faf000aea22216b544798159f0c801e796306d8b1ec9191abac5403177962da6d97aa85572cd3207d2fc1c971020ffe21429d7794e5f99893a1c8b7b923467d2ac5946d3ee6c3881c91b7092492964f483eb89e90fbd89cc94269ef43c860eb4cf880962b864c64d3c607976a028e33e06d82a03fd265a6b002529a63397c6bf94feb8f07ff4354822c83dac897e915b1db432dff9408ce1702811427a2101bf415bdb23f87d024535eced5c2b5428b89faf7157c9dc9b0f267971c19e9e4f1eea73a622ed9724b26b5b127925d96e7b74807fe6d01436e0a1e2c67f2c232bc125c07420f13e8907d75d20b074154c73c471da3e9d4800d55878aa3ebdbe1e09b09a3fb4f17f7f1b64b81a7cc791642de452f1c520c75cfb25751ec8fcc161f426d7ac599ce734bce5d59fcd569afda42855b2fd55a84f0c2f923cebe1e5ea4927126615220752e1598e64367a790a4cb17d33f5130929497a66a3f9f1860472354de18b27253e2cf725ff81dba4e3fa6cbfb34c41b71563bb127fa0217fcfe11172e06a7d21e20e2dea1928b9a5a52708740d7cf16a17524d8bffe488ffda8aa334cd56dad26a7d26566c8c519d304a377113c125e29c6b56e87b257d8492665017576d8bfeedc649a08e1ca1811f1851846886e26716204e1c989d8fe539f2c081a975753a53588cefc778b514404351019661dac86bf47a528bc96c18d21a61d253b041af0937e866a6954b96728d92e8df295ae72d5a093059fba11cc445b003239bc0c4fe4791c85aff42792a1cc1f68ae19171198bbcc3ea5909f7bab37e9edb173c01cef9c9917bcf937e677f3b5f037379477c9aaa88b958740352f0ada1d7fb865e2217014c05ef554431d7e9fd794a4721f077c873791af1fd2e8b21ef9b40236b577496d8cd3181ca38946d801eda92b4abb079161a1b277c93cf1b9a61f0c6a1d22c682b6a4da768d677203e11a0307c9f3884085610a523587bf0dd4c2da6d848e788135385ef6912c6004b9dd1e475eb98bf95f1120baf671002723ee6c7abe01a0b4585079346af93100cc768f56549d388b664464fbc893ecdb410b22c57c29ecccf180a1bf520f242582b1fccbbf4e50e7d950e8dc2183dae616d408c07cb9ccd0e5881ced920959f5dbf04dafbef08277572ddec1200cd9a2e8b896857168decca26488af448faee1f3e36fe5225b81903a747a36d5cfb6cb58e4884808dd4c88013471413074fcc81ba830663543827629a421e21aff2f6560c387819bae8a70c0b98399250b43943757c31ccdbaaae1ef1a8bc46867998ce3b3c19135042a5770345a079bc156705d4e0b4fb3cbc7a6c3de4f121f8f19880771e77b16c24e4c8637a2e69a2f0f207b677f27a0041d1edd14767e7033e0cce35686f21ec6c09f2cd57d19a0281a76c9aebaabeec2780615eba6a8b8b52d48ce2a5872b49f1f9b9d051df0c6a069602b608f5cfe794d361e4a838f3df677101a6f59df0e9ee66f1d4f9c28f9dbf4d1a0ea6fa27b3eeea0650861a51d944cf340113139d40f1bf41e0132ba788b6b429e860cb39f42f8c871675495a1f4a7f555c1b0c66ae6238237641a77f16db55ee4808c919b9d63796b6b1dbfe4f63648c6660a57c6b1ca79c02f134f80280e1fee3db661e83fe18292d5d36c5f714cd729098bd23a8f33e8b1794a6c1eaa678d16a6038f7b1ec14721a829daae46784c29e0f66557abb29104e401bcbe1e697c24d98b36f5462e0bf7a8a09da723739bcd34351ab7d8a4215c0c46f9177994d018773838fdb62556a968b9a0864644271592acfd9e66eb9634b9389f8278ab0a77e2919fe8672f23937f8cd9b507ba3176935382bf9c6cc78c729657696e89f460cc2400db3a75ae78f0f1aa962cc3df344a59617d2dafc134c2747d249efe69811ec3e9cc92c07bb37af011978e69dc35d4fea39aabbc0fcf6ae43a43aa6890b78aee075901c94c35b45da9f1702e30217cc03cbbd12792cf31ab1c5fb324562979d025d683982f016191d30aee2610c3ef842740aa2b1532c4b9658f1c737aa2b58de04bdec2914ab3b9fe97b59239e103d277d4d0d13768f6b8267dc03b692ace35f56e1828000413b32c3f0d26ff9c213b23efea0cabae6488cca1f00fafb2a186f7105f18b16a96a58ed9a7b00ebf13c714638d303474c6859c8922df02d97600ee26edae3acdc318df89ca14f463f41a1fdaa62e2c4b65c98abfaa2c9229377905a14153f71347c75b1b1f9190ede8de2bf427b5738be0c909f554e14af1bdd8ec1c43499382669b28ef4275667492a56e86c8215aed5a197eee4601ad3b8aa1f9b4546583ae2bdb6727302fab9313e5af2320e8a74faccc7866fdf6e81db6575ff3f163d11c448936717d3c08400d818ed27a66ced97a5f92ecb9c40bf7f4a1d51b2f4a1dee978a64705c62b0951faeec8107f031ab95c3b38536a61d3031b23c6a8da11feb5dca65cd6917d00ac9a0e03cdfea6de07a3080d2b8827dfee8c54a15a6d6d495d8833791a7077ed66eb6715c427a491e77cfc18b789bbf5ab90e9090aab702cccd9c251bc017f0dfed09e7c7164944fcdad014cd91448680665b263d46e6173c24ddde425e072bf3696f2cb498, 1),
('p12', 'Feemo PVC Saffari Gloves for E', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Cumque, consectetur.\r\nLorem ipsum dolor sit amet.', 500, 350, 0x52494646364c000057454250565038202a4c00003f3f013f012a580265023e51263f45233f21212953293f700a09696e3f3f5c3f3f3f663f3f3f3f703f3f3f52333f3b0f3f773f583f3f3f7b3f42483f3f3f3f6d3f453f3fc98f3f7e3f3f3f3f3f3f3f3f0e6c3f353f3f3f2f3f3f3f3f3f3f4f3f3f5c3f173f3f3f3f3fefb7af3f09623f023f3f3f3f373f1e3f787a7a3f7f3f3f433f3f3f3e3f3f3f3f5a3f3f7c3f3f3f2539293f4e4a72533f3f3f3f3f2539293f4e4a7253603f5f2539293f363f763c6f3f7c5b3f3f163f3fc5be290d3f3f3f3a3f1619393f153f3f3f2b323f093f0f3f7a2f3f5f443f3f373f073f155ad2893f7c3f3f3f603f0e3f3f294e1d234d3fc7bb573f3f3f47673f3f563f7d763e53320a4a3f18663f0c593f2d671d3fdea7452a3f3fd8bfd99734013f3f1c3f0e3f3f096e663f3f65033379383f3f0a323f3f753f643f3f163f2a443f633f443f3f3f6f2d3f3f3f7568093f423f3f3e3f3f3f3f3f613f3f013f3f6dc3a33f71377b34413f0b3f3d3f46dfb7703e1e3f3f06ee8d93743f7f3f0a183f5b3f563f283f663f2d617c3f3f4b203f2f3f6f033f3f3f752076443f3f7e4c283f3f187c3759672a30473f3f59663f3f3fcbb02a343f3f523f3f3f4e3f3f3f3f653f3f3f3f465a0c3f3f2a3fd49f3fcc8d3f7f3f3b3f083f460f0e79183f3f303f0d3f3f113f2e0775133f272f643f3f343f3fecb291514e, 1),
('p13', 'Feemo PVC Saffari Mobile_cover', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. corem llorem', 800, 650, 0x3f3f3f3f00104a464946000101000001000100003f3f0043000b08080808080b08080b100b090b10130e0b0b0e1316121213121216151113121213111515191a1b1a1915212124242121302f2f2f30363636363636363636363f3f0043010c0b0b0c0d0c0f0d0d0f130e0e0e13140e0f0f0e141a12121412121a22181515151518221e201b1b1b201e2525222225252f2f2c2f2f363636363636363636363f3f001108053f053f030122000211010311013f3f001f0000010501010101010100000000000000000102030405060708090a0b3f3f003f100002010303020403050504040000017d01020300041105122131410613516107227114323f3f3f0823423f3f15523f3f243362723f090a161718191a25262728292a3435363738393a434445464748494a535455565758595a636465666768696a737475767778797a3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f001f0100030101010101010101010000000000000102030405060708090a0b3f3f003f1100020102040403040705040400010277000102031104052131061241510761711322323f0814423f3f3f3f092333523f1562723f0a1624343f253f1718191a262728292a35, 1),
('p14', 'Feemo PVC Saffari Raincoat for', 'Seam seal is used with tapes for a more waterproofing experience. Superior quality best raincoat for Kids.', 1350, 899, 0x524946463f3f000057454250565038580a0000000c0000003f06003f060056503820763f00003f21063f012a400640063e51283f463f3f28263f3f3f3f000a09676e3f3f2e3f293f673f3f76caa43f0d3f0d1b3f5b3f3f3f3f3f3f0f3f023fd9933f363f2d3f72053a2f456f3f3f1f423f3f3f3f3f71332f3f3f3f3f3f3fcf947c553fcfb33f3f3d3f3f3f3f1e5fde813f3f3f7f3fdf991f3a7f3f3f3f7b3f3f3f3f0b3f7f3f3f3f3f3f5f3f5f3f3e3f3f3f7e3f7b3f3f773f3f3f073f773f373f3f3f3fdc8f7a7fd4bf3f7e3f3f3f3f093f3f3f333f3f3f3f3f3f3f3f3f3f3f3f3f7f3f3f3f3f573f3f3f3f3f3f696f3f3f3f1f123f3f7f3f7e3f3f627f3f3f003f3f3f3f3f1f3f7f3f7c3f7c3f3f3f067f393f7f3f5e093f433f7d3f6e3f3f6c3f1dc99e3f4e3f3f773f1f3f3f3f3f3f7e673f3f6b3f3f7b3f3f3f3f3f3f3f3f3f3f373f3f3f7b077f373f253f4d3f273f073f3f443f617f3f3f713f353f213f3f3f033f3f3f033f3f343f3f2d7e4055453f321158163f202a3f3f3f083f0b5f3f155176cc8456053f3f0a3f3f66422b023f3f05545d3f21153f6b3f023f2ed9903f3f3f3f0155176c3f45605a3f3f3f3f3f64223f2d7e4055453f321158163f202a3f3f3f083f0b5f3f155176cc8456053f3f0a3f3f66422b0223173f2a03cbb5461e3f322d3f6a20163f202a3f3f3f083f0b5f3f155176cc8456053f3f0a3f3f, 1),
('p15', 'Feemo Women Raincoat', 'Seam seal is used with tapes for a more waterproofing experience. Superior quality best raincoat for women.', 1000, 899, 0x524946463f4d000057454250565038580a000000080000003f02003f0200565038203f4c0000303f013f012a000300033e51283f463f3f213f3f3fc8b03f0a09676e3f253f3f021c5e753f05781e3f3f09e2bcb33f3f4d3f3f3f3f0f3f3f773f493f673f3e2e7c0f3f3fd7bb033f6f303f343f3f3f1f3f3f3f3f3f3f3f7d737f3f3f0d3f3f3f3f3f3f3f5f3f5f3f3f3f3f3f3f3f7f3f3f513f3f3f5b3f1f3f3f783f3f3f3f7f3f3f693f3f3f133f3f3f2f3f3fd19e3f3f3f3f3f3f0a7f2f3f5f3f2f3f5f3f173f3f3f3f3f6f3f1f3f3f3f3f3f7f3f3f007f3f3f003f3f3f2f3f3f2c3f213f6b3f173f7f3f3f773f3f3f3f3f3f0d3f3f703fdcbe3f313f3f3f04753f3f1f3f3f3f0f3f7f3f7d3f3f597f3f7a3f3f573f2b3f7f3f3f3f7b3f3f413f3f3f3f3f3f3f1f3f5f3f1e3f7e3f0a5a483f473f6f3f2b3f3f470a3d2b7c795e3f3f38513f5b3f3f3f343fc28f493f3f431a283f3f3f3f1bdfa9525e603f3f587f13063f3f503f3fc28f4a3f1e573f3f3f147a563f3f3f0d1c2f303f353f1fc7bd5d7b3f2c3f6cd7af4911613f313f3f3f7454333f3f3f563f3f3f0d24703fd2b7c7953f69233f673f283f3f5d3f3f3f3f5d6d3f4e3d3f7d7d3f363f3f133f3b3f3f01c4b53f147a563f3f3f0d24703fd2b7c7953f4e403f3f1b3f31563f3b513f353f6e3f3f3f443f1f3f3f3f3f2e1d314d3f513f053f3f563f3f3f0d24703fd2b7c7953f, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `emails` varchar(50) NOT NULL,
  `passi` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`fname`, `lname`, `emails`, `passi`) VALUES
('Anu', 'Zaman', 'drago@gmail.com', 123456);

-- --------------------------------------------------------

--
-- Table structure for table `women`
--

CREATE TABLE `women` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `descr` varchar(200) NOT NULL,
  `price` int(10) NOT NULL,
  `dprice` int(10) NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `women`
--

INSERT INTO `women` (`id`, `name`, `descr`, `price`, `dprice`, `image`) VALUES
(201, 'Feemo Cloth Raincoat for Women', 'Seam seal is used with tapes for a more waterproofing experience. Superior quality best raincoat for women.', 1000, 650, '/images/women11.jpg'),
(202, 'Feemo Cloth Raincoat for Women2', ' Seam seal is used with tapes for a more waterproofing experience. Superior quality best raincoat for women.', 1350, 899, '/images/women2.jpg'),
(203, 'Feemo Cloth Raincoat for Women', 'Seam seal is used with tapes for a more waterproofing experience. Superior quality best raincoat for women.', 2000, 1200, 'images/women3.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `access2`
--
ALTER TABLE `access2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `accessories`
--
ALTER TABLE `accessories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`aID`,`aemail`);

--
-- Indexes for table `kids`
--
ALTER TABLE `kids`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mens`
--
ALTER TABLE `mens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`email`,`phone`);

--
-- Indexes for table `ordered_items`
--
ALTER TABLE `ordered_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`emails`);

--
-- Indexes for table `women`
--
ALTER TABLE `women`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
