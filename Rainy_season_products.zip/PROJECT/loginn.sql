-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:4306
-- Generation Time: Sep 05, 2023 at 04:58 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `loginn`
--

-- --------------------------------------------------------

--
-- Table structure for table `access2`
--

CREATE TABLE `access2` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `descr` varchar(200) NOT NULL,
  `price` int(10) NOT NULL,
  `dprice` int(10) NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `access2`
--

INSERT INTO `access2` (`id`, `name`, `descr`, `price`, `dprice`, `image`) VALUES
(501, 'Feemo PVC Mobile Cover', 'Seam seal is used with tapes. Superior quality Covers.', 900, 799, '/images/mobile_cover.jpg'),
(601, 'LappyRella Waterproof Cover for 15.6 inch Laptop', '🌊 Water-proof Laptop Cover, Dust-proof, Scratch-proof: Have peace of mind in rains. Separate Inside Partition Flap for Laptop and Accessories. No need to search for cables and accessories inside your ', 699, 179, 'https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.amazon.in%2FLappyRella-Waterproof-Laptop-Dustproof-Scratch%2Fdp%2FB07X6QSM79&psig=AOvVaw0MvJiNMnxX__SPrFwSPOei&ust=1693840686348000&source=images&cd=vfe&opi=89978449&ved=0CBAQjRxqFwoTCNj7orXejoEDFQAAAAAdAAAAABAH');

-- --------------------------------------------------------

--
-- Table structure for table `accessories`
--

CREATE TABLE `accessories` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `descr` varchar(200) NOT NULL,
  `price` int(10) NOT NULL,
  `dprice` int(10) NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accessories`
--

INSERT INTO `accessories` (`id`, `name`, `descr`, `price`, `dprice`, `image`) VALUES
(401, 'Feemo PVC Saffari Umbrella for You', 'Seam seal is used with tapes. Superior quality Umbrella.', 300, 150, '/images/favourites.png'),
(402, 'Feemo PVC Saffari Gloves for Everyone', 'Seam seal is used with tapes. Superior quality Gloves.', 500, 350, '/images/gloves.jpg'),
(403, 'Feemo PVC Mobile Covers', 'Seam seal is used with tapes. Superior quality Covers.', 800, 650, '/images/mobile_cover.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `aname` varchar(100) NOT NULL,
  `aemail` varchar(100) NOT NULL,
  `apass` bigint(20) NOT NULL,
  `aID` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`aname`, `aemail`, `apass`, `aID`) VALUES
('farhadullfhs@gmail.com', 'Farhadul Zaman', 123456789, 20);

-- --------------------------------------------------------

--
-- Table structure for table `kids`
--

CREATE TABLE `kids` (
  `name` varchar(100) NOT NULL,
  `descr` varchar(100) NOT NULL,
  `dprice` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `image` varchar(500) NOT NULL,
  `id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kids`
--

INSERT INTO `kids` (`name`, `descr`, `dprice`, `price`, `image`, `id`) VALUES
('Feemo PVC Saffari Raincoat for Kids', 'Seam seal is used with tapes. Superior quality raincoat for kids.', 350, 850, '/images/kids1.jpg', 101),
('Feemo PVC Saffari Raincoat for Kids2', 'Seam seal is used with tapes. Superior quality raincoat for kids.', 500, 1000, '/images/kids2.jpg', 102),
('Feemo PVC Saffari Raincoat for Kids3', 'Seam seal is used with tapes. Superior quality raincoat for kids.', 899, 1500, '/images/kids4.jpg', 103);

-- --------------------------------------------------------

--
-- Table structure for table `mens`
--

CREATE TABLE `mens` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `descr` varchar(200) NOT NULL,
  `price` int(10) NOT NULL,
  `dprice` int(10) NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mens`
--

INSERT INTO `mens` (`id`, `name`, `descr`, `price`, `dprice`, `image`) VALUES
(1, 'Feemo Cloth Reversible Raincoat 1', 'Superior quality best raincoat for men.', 2380, 1380, '/images/men1.jpg'),
(2, 'Feemo Cloth Reversible Raincoat 2', 'Superior quality best raincoat for men.', 2220, 1005, '/images/men2.jpg'),
(3, 'Feemo Cloth Reversible Raincoat 3', 'Superior quality best raincoat for men.', 3000, 1999, '/images/men3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `ordered_items`
--

CREATE TABLE `ordered_items` (
  `id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` int(20) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `product_quantity` int(10) NOT NULL,
  `order_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `city` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(12) NOT NULL,
  `date` datetime(6) NOT NULL,
  `cost` bigint(20) NOT NULL,
  `product_ids` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL,
  `transaction_id` bigint(20) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` varchar(100) NOT NULL,
  `name` varchar(30) NOT NULL,
  `descr` varchar(300) NOT NULL,
  `price` int(10) NOT NULL,
  `dprice` int(10) NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `descr`, `price`, `dprice`, `image`) VALUES
('p11', 'Feemo pinky umbrella', 'Seam seal is used with tapes for a more waterproofing experience. Superior quality best umbrella.', 300, 150, '/html/images/pink_umbrella.jpg'),
('p12', 'Feemo PVC Saffari Gloves for E', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Cumque, consectetur.\r\nLorem ipsum dolor sit amet.', 500, 350, 'RIFF6L\0\0WEBPVP8 *L\0\0???*Xe>Q&?E#?!!)S)?p\n	in??\\???f????p???R3?;?w?X???{?BH????m?E??ɏ?~????????l?5???/??????O??\\??????﷯?	b?????7??xzz???C???>????Z??|???%9)?NJrS?????%9)?NJrS`?_%9)?6?v<o?|[????ž)\r???:?9????+2?	??z/?_D??7??Z҉?|???`???)N#M?ǻW???Gg??V?}v>S2\nJ?f?Y?-g?ާE*??ؿٗ4?????	nf??e3y8??\n2??u?d???*D?c?D???o-???uh	?B??>?????a????mã?q7{4A??=?F߷p>??t??\n?[?V?(?f?-a|??K ?/?o???u vD??~L(??|7Yg*0G??Yf???˰*4??R???N????e????FZ??*?ԟ?̍??;??Fy??0?\r???.u?\'/d??4??첑QN'),
('p13', 'Feemo PVC Saffari Mobile_cover', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. corem llorem', 800, 650, '????\0JFIF\0\0\0\0\0\0??\0C\0	\Z\Z!!$$!!0///06666666666??\0C\r\r\r\Z\Z\"\"  %%\"\"%%//,//6666666666??\0??\"\0??\0\0\0\0\0\0\0\0\0\0\0	\n??\0?\0\0\0}\0!1AQa\"q2???#B??R??$3br?	\n\Z%&\'()*456789:CDEFGHIJSTUVWXYZcdefghijstuvwxyz???????????????????????????????????????????????????????????????????????????\0\0\0\0\0\0\0\0	\n??\0?\0\0w\0!1AQaq\"2?B????	#3R?br?\n$4?%?\Z&\'()*5'),
('p14', 'Feemo PVC Saffari Raincoat for', 'Seam seal is used with tapes for a more waterproofing experience. Superior quality best raincoat for Kids.', 1350, 899, 'RIFF??\0\0WEBPVP8X\n\0\0\0\0\0\0?\0?\0VP8 v?\0\0?!?*@@>Q(?F??(&????\0\n	gn??.?)?g??vʤ?\r?\r?[????????ٓ?6?-?r:/Eo??B?????q3/??????ϔ|U?ϳ??=????_ށ????ߙ:???{??????????_?_?>???~?{??w????w?7????܏zԿ?~????	???3?????????????????W??????io??????~??b??\0???????|?|???9??^	?C?}?n??l?ɞ?N??w??????~g??k??{??????????7???{7?%?M?\'???D?a??q?5?!????????4??-~@UE?2X? *????_?Qv̄V??\n??fB+??T]?!?k??.ِ????Ul?E`Z?????d\"?-~@UE?2X? *????_?Qv̄V??\n??fB+#?*˵F?2-?j ? *????_?Qv̄V??\n??'),
('p15', 'Feemo Women Raincoat', 'Seam seal is used with tapes for a more waterproofing experience. Superior quality best raincoat for women.', 1000, 899, 'RIFF?M\0\0WEBPVP8X\n\0\0\0\0\0\0?\0?\0VP8 ?L\0\00??*\0\0>Q(?F??!???Ȱ?\n	gn?%??^u?x??	⼳??M??????w?I?g?>.|??׻?o0?4??????????}s??\r???????_?_?????????Q???[???x??????i??????/??ў??????\n/?_?/?_??????o????????\0??\0???/??,?!?k????w??????\r??p?ܾ?1???u???????}??Y?z??W?+????{??A????????_??~?\nZH?G?o?+??G\n=+|y^??8Q?[???4?I??C\Z(????ߩR^`??X??P??J?W???zV???\r/0?5?ǽ]{?,?lׯIa?1???tT3???V???\r$p?ҷǕ?i#?g?(??]????]m?N=?}}?6???;??ĵ?zV???\r$p?ҷǕ?N@???1V?;Q?5?n???D?????.1M?Q???V???\r$p?ҷǕ?');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `emails` varchar(50) NOT NULL,
  `passi` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`fname`, `lname`, `emails`, `passi`) VALUES
('Anu', 'Zaman', 'drago@gmail.com', 123456);

-- --------------------------------------------------------

--
-- Table structure for table `women`
--

CREATE TABLE `women` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `descr` varchar(200) NOT NULL,
  `price` int(10) NOT NULL,
  `dprice` int(10) NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `women`
--

INSERT INTO `women` (`id`, `name`, `descr`, `price`, `dprice`, `image`) VALUES
(201, 'Feemo Cloth Raincoat for Women', 'Seam seal is used with tapes for a more waterproofing experience. Superior quality best raincoat for women.', 1000, 650, '/images/women11.jpg'),
(202, 'Feemo Cloth Raincoat for Women2', ' Seam seal is used with tapes for a more waterproofing experience. Superior quality best raincoat for women.', 1350, 899, '/images/women2.jpg'),
(203, 'Feemo Cloth Raincoat for Women', 'Seam seal is used with tapes for a more waterproofing experience. Superior quality best raincoat for women.', 2000, 1200, 'images/women3.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `access2`
--
ALTER TABLE `access2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `accessories`
--
ALTER TABLE `accessories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`aID`,`aemail`);

--
-- Indexes for table `kids`
--
ALTER TABLE `kids`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mens`
--
ALTER TABLE `mens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ordered_items`
--
ALTER TABLE `ordered_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`emails`);

--
-- Indexes for table `women`
--
ALTER TABLE `women`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
